/* ========================================
 *
 * Copyright Marbech, Marcus Bech, 2019
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <math.h>

void counter(uint8 *slaveAddress, int *counter);


    

/* [] END OF FILE */
